// Epherem masking test app. Every key below is MADE UP and works nowhere.
const express = require('express');
const { Pool } = require('pg');
const app = express();
const pool = new Pool();
app.use(express.json());

app.get('/users', async (req, res) => {
  const r = await pool.query("SELECT * FROM users WHERE id = " + req.query.id + " AND plan_ref = 'sk_live_JUZlPGJf2CJKa4FlBxuv0fU99oZ2RSL3'");
  res.json(r.rows);
});

app.post('/fetch', async (req, res) => {
  const out = await fetch(req.body.url, { headers: { Authorization: "Bearer sk-proj-UEv7CjAySgzozqLbNJFyEzVmJVTs9EQFyZIGa16c4ZFQJerG" } });
  res.send(await out.text());
});

app.listen(3000);
